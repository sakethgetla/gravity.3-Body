package gravity;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;

public class buttons {

	public buttons(int x ,int y ,int width , int height, String  name){
		int button[] = new int[4];
		button[0] = x ;
		button[1] = y ;
		button[2] = x + width ;
		button[3] = y + height ;
		 
		
		
	}
	private void graphics(Graphics g) {
		
	}
	
}
